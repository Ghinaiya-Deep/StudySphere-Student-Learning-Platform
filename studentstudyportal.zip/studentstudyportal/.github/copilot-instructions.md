## Quick context — what this repo is

- Django web app (single app) named `dashboard` inside the project `studentstudyportal`.
- DB: SQLite file at `db.sqlite3` (development). Templates live under `dashboard/templates/dashboard/`. Static files live at `static/` and are referenced via `STATICFILES_DIRS` in `studentstudyportal/settings.py`.
- Key third-party packages referenced in code: `crispy_forms` (Django Crispy Forms), `requests`, and `wikipedia` (python package). The project was scaffolded with Django 3.2.x (see `settings.py`).

## Big-picture architecture (what to open first)

- `manage.py` — Django CLI entry (standard). Use it for running the server, migrations, tests.
- `studentstudyportal/settings.py` — project settings: DEBUG=True, SQLite, `INSTALLED_APPS` includes `dashboard` and `crispy_forms`, static dirs configured.
- `studentstudyportal/urls.py` — project routes (admin, auth, includes `dashboard.urls`).
- `dashboard/urls.py` — app routes and route names (important names: `home`, `notes`, `todo`, `homework`, `books`, `dictionary`, `wiki`, `conversion`).
- `dashboard/views.py` — business logic for all pages. Look here for API usage (Google Books via `requests`, dictionary API via `requests`, and `wikipedia` package).

## How to run locally (Windows PowerShell)

1. Open a PowerShell terminal in the project root (where `manage.py` is).

2. (Optional but recommended) create & activate a virtualenv:

```powershell
python -m venv venv
# Allow the current PowerShell session to run local activation scripts if blocked:
Set-ExecutionPolicy -ExecutionPolicy RemoteSigned -Scope Process
.\venv\Scripts\Activate.ps1
```

3. Install runtime dependencies (a pinned `requirements.txt` is included in the repo):

```powershell
pip install -r requirements.txt
```

4. Prepare DB and run dev server:

```powershell
python manage.py migrate
python manage.py createsuperuser   # optional: create admin user for /admin/
python manage.py runserver 0.0.0.0:8000
```

5. Open the site at http://127.0.0.1:8000/ (or use the host/port you supplied).

6. Useful commands:

```powershell
python manage.py test       # run tests
python manage.py shell      # open Django shell
```

## Project-specific conventions & patterns

- Single Django app `dashboard` contains most logic (models/forms/views/templates). When extending, follow this single-app pattern rather than creating many small apps.
- Route names are used in templates and redirects (example: `LOGIN_REDIRECT_URL = 'home'` in `settings.py`; view `home` is defined in `dashboard/urls.py`). Use the named routes instead of hardcoded paths.
- Templates: use `dashboard/<template>.html` under `dashboard/templates/dashboard/`. Edit templates there.
- Static assets: `static/` is referenced via `STATICFILES_DIRS`. During development static files are served automatically by runserver; for production you would run `collectstatic` (not present/needed for dev).

## Integration points / external calls to watch for

- Google Books API: `dashboard/views.py -> books()` builds a URL against `https://www.googleapis.com/books/v1/volumes?q=` and uses `requests`. No API key present.
- Dictionary API: `https://api.dictionaryapi.dev/...` used in `dashboard/views.py -> dictionary()` via `requests`.
- Wikipedia: the `wikipedia` python package is used in `dashboard/views.py -> wiki()`.

When writing tests or stubbing network calls, mock `requests.get` and `wikipedia.page`.

## Debugging tips (concrete)

- If Django import errors occur: ensure virtualenv is activated and `pip install` ran. `manage.py` error message already hints at virtualenv problems.
- If PowerShell refuses to run `.\venv\Scripts\Activate.ps1`, use the `Set-ExecutionPolicy` command shown above for that session.
- If templates don’t render expected variables, open `dashboard/views.py` for the view name in `dashboard/urls.py` and inspect the `context` dict the view passes to `render()`.

## Files to inspect for most change tasks

- Add/edit routes: `dashboard/urls.py` and `studentstudyportal/urls.py`.
- Implement logic: `dashboard/views.py` (examples: `notes()`, `todo()`, `books()`).
- Forms: `dashboard/forms.py` (used widely by views).
- Models & migrations: `dashboard/models.py` and `dashboard/migrations/` (DB schema is SQLite `db.sqlite3`).

## Edge cases & notes discovered from code

- The repo sets `DEBUG = True` and includes a hard-coded `SECRET_KEY` in `settings.py` — safe for local dev only. Do not reuse for production.
- There is now a `requirements.txt` with pinned versions for the packages the code references. Install with `pip install -r requirements.txt`.
- `db.sqlite3` exists in repo root; running `migrate` is still recommended (it will be a no-op if schema is already current).

---
If you'd like, I can also:
- generate a `README.md` with these run steps, or
- create a VS Code debug task for launching the Django dev server.

Please tell me which addition you want or where you'd like this file adjusted.
